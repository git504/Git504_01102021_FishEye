# Projet n°6 OpenClassRoom parcours frontend

## Mission : intégration avec du contenu dynamique

Client : FishEye est un site web qui permet aux photographes indépendants de présenter leurs meilleurs travaux.

## Compétences évaluées :

- [x] Développer une application web modulaire avec des design patterns
- [x] Assurer l'accessibilité d'un site web
- [x] Écrire du code JavaScript maintenable
- [x] Gérer les événements du site avec JavaScript

## Run project :

- [x] `npm run start` to start server on http://localhost:9000/

[LIEN REPO GITHUB](https://github.com/git504/Git504_01102021_FishEye)
